/*function palindrome(str) {
    revStr = str.split('').reverse().join('');
    if(str.toLowerCase() === revStr.toLowerCase()) return true;
    return false;
}*/



console.log(palindrome('malayalam'));